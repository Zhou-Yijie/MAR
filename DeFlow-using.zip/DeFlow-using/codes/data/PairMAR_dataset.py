import random
import numpy as np
import cv2
import torch
import torch.utils.data as data
import data.util as util


def getEnv(name): import os; return True if name in os.environ.keys() else False


def read_simulated_datah5(filename: str, withnorm=False, window=None):
    '''
    Use for test process. Get ndarray back. Manually load to tensor please. 
    This function does not normalize the read data.
    '''
    with h5py.File(filename, mode='r') as f:
        data_gt = np.array(f['gt_CT']) # f['gt_CT'] with shape (H, W)
        data_ma = np.array(f['ma_CT']) # f['ma_CT'] with shape (1, H, W)
        data_metalmask = np.array(f['metal_mask']) # f['metal_mask'] with shape (1, H, W)
        data_ma = data_ma[0]
        data_metalmask = data_metalmask[0]

        
    if withnorm:
        if window is not None:
            miuwater = 0.192
            minval, maxval = window
            minval = minval / 1000 * miuwater + miuwater
            maxval = maxval / 1000 * miuwater + miuwater
        else:
            minval, maxval = get_minmax()

        # data_gt = (data_gt - minval) / (maxval - minval)
        # data_ma = (data_ma - minval) / (maxval - minval)
        data_gt = normalize(data_gt, (minval, maxval))
        data_ma = normalize(data_ma, (minval, maxval))

    # return all data with single image shape (H, W)
    data = {
        "gt_image": data_gt,
        "ma_image": data_ma,
        "metal_mask": data_metalmask,
        "filename": filename
    }
    return data



class LQGTDataset(data.Dataset):
    '''
    Read LQ (Low Quality, here is LR) and GT image pairs.
    If only GT image is provided, generate LQ image on-the-fly.
    The pair is ensured by 'sorted' function, so please check the name convention.
    '''

    def __init__(self, opt):
        super(LQGTDataset, self).__init__()
        self.opt = opt
        self.data_type = self.opt['data_type']
        self.paths_LQ, self.paths_GT = None, None
        self.sizes_LQ, self.sizes_GT = None, None
        self.LQ_env, self.GT_env = None, None  # environment for lmdb

        dataroot_GT = opt['dataroot_GT']
        dataroot_LQ = opt['dataroot_LQ']
        y_labels_file_path  = opt['dataroot_y_labels']

        self.dataroot_GT = dataroot_GT
        self.dataroot_LQ = dataroot_LQ

        self.paths_GT, self.sizes_GT = util.get_image_paths(self.data_type, dataroot_GT)
        self.paths_LQ, self.sizes_LQ = util.get_image_paths(self.data_type, dataroot_LQ)

        if y_labels_file_path is not None:
            self.y_labels = []
            with open(y_labels_file_path, "rb") as f:
                self.y_labels += pickle.load(f)
            self.y_labels[:n_max]
        else:
            self.y_labels = None

        n_max = opt.get('n_max', None)
        if n_max is not None:
            if n_max > 0:
                self.paths_GT = self.paths_GT[:n_max]
                self.paths_LQ = self.paths_LQ[:n_max]
            elif n_max < 0:
                self.paths_GT = self.paths_GT[n_max:]
                self.paths_LQ = self.paths_LQ[n_max:]
            else:
                raise RuntimeError("Not implemented")


        assert self.paths_GT, 'Error: GT path is empty.'
        print(len(self.paths_GT), self.paths_GT[:10])
        if self.paths_LQ and self.paths_GT:
            assert len(self.paths_LQ) == len(
                self.paths_GT
            ), 'GT and LQ datasets have different number of images - {}, {}.'.format(
                len(self.paths_LQ), len(self.paths_GT))
        self.random_scale_list = [1]

    def _init_lmdb(self):
        # https://github.com/chainer/chainermn/issues/129
        self.GT_env = lmdb.open(self.dataroot_GT, readonly=True, lock=False, readahead=False,
                                meminit=False)
        self.LQ_env = lmdb.open(self.dataroot_LQ, readonly=True, lock=False, readahead=False,
                                meminit=False)

    def __getitem__(self, index):
        if self.data_type == 'lmdb':
            if (self.GT_env is None) or (self.LQ_env is None):
                self._init_lmdb()
        GT_path, LQ_path = None, None
        scale = self.opt['scale']
        GT_size = self.opt['GT_size']

        # get GT image
        GT_path = self.paths_GT[index]
        if self.data_type == 'lmdb':
            resolution = [int(s) for s in self.sizes_GT[index].split('_')]
        else:
            resolution = None
        img_GT = util.read_img(self.GT_env, GT_path, resolution)
        # modcrop in the validation / test phase
        if self.opt['phase'] != 'train':
            img_GT = util.modcrop(img_GT, scale)
        # change color space if necessary
        if self.opt['color']:
            img_GT = util.channel_convert(img_GT.shape[2], self.opt['color'], [img_GT])[0]

        # get LQ image
        if self.paths_LQ:
            LQ_path = self.paths_LQ[index]
            if self.data_type == 'lmdb':
                resolution = [int(s) for s in self.sizes_LQ[index].split('_')]
            else:
                resolution = None
            img_LQ = util.read_img(self.LQ_env, LQ_path, resolution)
        else:  # down-sampling on-the-fly
            # randomly scale during training
            if self.opt['phase'] == 'train':
                random_scale = random.choice(self.random_scale_list)
                H_s, W_s, _ = img_GT.shape

                def _mod(n, random_scale, scale, thres):
                    rlt = int(n * random_scale)
                    rlt = (rlt // scale) * scale
                    return thres if rlt < thres else rlt

                H_s = _mod(H_s, random_scale, scale, GT_size)
                W_s = _mod(W_s, random_scale, scale, GT_size)
                img_GT = cv2.resize(np.copy(img_GT), (W_s, H_s), interpolation=cv2.INTER_LINEAR)
                # force to 3 channels
                if img_GT.ndim == 2:
                    img_GT = cv2.cvtColor(img_GT, cv2.COLOR_GRAY2BGR)

            H, W, _ = img_GT.shape
            # using matlab imresize
            img_LQ = util.imresize_np(img_GT, 1 / scale, True)
            if img_LQ.ndim == 2:
                img_LQ = np.expand_dims(img_LQ, axis=2)

        if self.opt['phase'] == 'train':
            # if the image size is too small
            H, W, _ = img_GT.shape
            if H < GT_size or W < GT_size:
                img_GT = cv2.resize(np.copy(img_GT), (GT_size, GT_size),
                                    interpolation=cv2.INTER_LINEAR)
                # using matlab imresize
                img_LQ = util.imresize_np(img_GT, 1 / scale, True)
                if img_LQ.ndim == 2:
                    img_LQ = np.expand_dims(img_LQ, axis=2)

            H, W, C = img_LQ.shape
            LQ_size = GT_size // scale

            # randomly crop
            debug_idx = random.randint(0, 10000)
            if getEnv("DEBUG_DATASET_IMAGES"):
                import imageio
                label = img_LQ
                print("img_LQ_before_crop", label.min(), label.max(), label.shape)
                imageio.imwrite("./{}img_LQ_before_crop.png".format(debug_idx), label)
                label = img_GT
                print("img_GT_before_crop", label.min(), label.max(), label.shape)
                imageio.imwrite("./{}img_GT_before_crop.png".format(debug_idx), label)

            rnd_h = random.randint(0, max(0, H - LQ_size))
            rnd_w = random.randint(0, max(0, W - LQ_size))
            img_LQ = img_LQ[rnd_h:rnd_h + LQ_size, rnd_w:rnd_w + LQ_size, :]
            rnd_h_GT, rnd_w_GT = int(rnd_h * scale), int(rnd_w * scale)
            img_GT = img_GT[rnd_h_GT:rnd_h_GT + GT_size, rnd_w_GT:rnd_w_GT + GT_size, :]

            if getEnv("DEBUG_DATASET_IMAGES"):
                import imageio
                # import random
                label = img_LQ
                print("img_LQ_after_crop", label.min(), label.max(), label.shape)
                imageio.imwrite("./{}img_LQ_after_crop.png".format(debug_idx), label)
                label = img_GT
                print("img_GT_after_crop", label.min(), label.max(), label.shape)
                imageio.imwrite("./{}img_GT_after_crop.png".format(debug_idx), label)

            # augmentation - flip, rotate
            img_LQ, img_GT = util.augment([img_LQ, img_GT], self.opt['use_flip'],
                                          self.opt['use_rot'])

        # change color space if necessary
        if self.opt['color']:
            img_LQ = util.channel_convert(C, self.opt['color'],
                                          [img_LQ])[0]

        if 'use_center_crop' in self.opt.keys() and self.opt['use_center_crop'] == True:
            img_GT = centercrop(img_GT, self.opt['GT_size'])
            img_LQ = centercrop(img_LQ, self.opt['GT_size'] // self.opt['scale'])

        # BGR to RGB, HWC to CHW, numpy to tensor
        if img_GT.shape[2] == 3:
            img_GT = img_GT[:, :, [2, 1, 0]]
            img_LQ = img_LQ[:, :, [2, 1, 0]]
        img_GT = torch.from_numpy(np.ascontiguousarray(np.transpose(img_GT, (2, 0, 1)))).float()
        img_LQ = torch.from_numpy(np.ascontiguousarray(np.transpose(img_LQ, (2, 0, 1)))).float()

        if LQ_path is None:
            LQ_path = GT_path
        return {'LQ': img_LQ, 'GT': img_GT, 'LQ_path': LQ_path, 'GT_path': GT_path}

    def __len__(self):
        return len(self.paths_GT)


def centercrop(img, size):
    x, y, c = img.shape
    assert c == 3, (x, y, c)

    x_start = x // 2 - size // 2
    x_end = x_start + size

    y_start = x // 2 - size // 2
    y_end = x_start + size

    return img[x_start:x_end, y_start:y_end]
