# install 

## test for the code
python train.py -opt ./confs/DeFlow-AIM-RWSR-test.yml



## modify the code
python train.py -opt ./confs/DeFlow-RWSR-MAR.yml