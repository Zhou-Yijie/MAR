wget https://polybox.ethz.ch/index.php/s/CK1fGHoPjZ3kS5l/download -O DeFlow_models.zip;
unzip DeFlow_models.zip -d DeFlow_models && rm DeFlow_models.zip;
