wget https://polybox.ethz.ch/index.php/s/eJ97Id5qwKs9fhN/download -O ESRGAN_models.zip;
unzip ESRGAN_models.zip -d ESRGAN_models && rm ESRGAN_models.zip;
