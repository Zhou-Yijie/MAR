wget https://polybox.ethz.ch/index.php/s/hBRoH6Rg9KeMJ2n/download -O RRDB_models.zip;
unzip RRDB_models.zip -d RRDB_models && rm RRDB_models.zip;
