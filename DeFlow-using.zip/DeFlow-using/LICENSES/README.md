# License and Acknowledgement

DeFlow and our code contributions are released under the Apache 2.0 license.

A big thanks to the following contributors that open sourced their code and therefore helped us a lot in developing DeFlow!

## SRFlow
The condtitional flow modules and training scripts were adapted from https://github.com/andreas128/SRFlow

## BasicSR
The training framework was adapted from https://github.com/xinntao/BasicSR

## GLOW
The Normalizing Flow modules were adapted from https://github.com/chaiyujin/glow-pytorch
